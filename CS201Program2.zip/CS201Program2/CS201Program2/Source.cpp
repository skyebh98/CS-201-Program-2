//Skye Hewitt
//sbhngh@mail.umkc.edu
//CS201 
//Pogram 2 - Bank


#include <iostream>
#include <fstream>
#include <iomanip> //To modify outputted string length
#include <string>

using namespace std;


void outputMenu() {

	cout << "1. Print all customer data" << endl;
	cout << "2. Print names and IDs" << endl;
	cout << "3. Print Account totals" << endl;
	cout << "'Q' to quit" << endl;
	cout << "Enter an option ==> ";

}


void PrintCustomerData(const int ID[], const string firstNames[], const string lastNames[], const double savingsAccount[], const double checkingAccount[], int size) {

	cout << setw(10) << left << "ID: ";
	cout << setw(10) << "First: ";
	cout << setw(15) << "Last: ";
	cout << setw(20) << "Savings Account: ";
	cout << setw(20) << "Checking Account: " << endl;

	for (int index = 0; index < size; ++index) {

		cout << setw(10) << ID[index];
		cout << setw(10) << firstNames[index];
		cout << setw(15) << lastNames[index];
		cout << setw(20) << savingsAccount[index];
		cout << setw(20) << checkingAccount[index] << endl;

	}
	cout << endl << endl;
}

void PrintNames(const int ID[], const string firstNames[], const string lastNames[], int size) {

	cout << setw(10) << left << "ID: ";
	cout << setw(10) << "First: ";
	cout << setw(15) << "Last: " << endl;

	for (int index = 0; index < size; ++index) {

		cout << setw(10) << ID[index];
		cout << setw(10) << firstNames[index];
		cout << setw(15) << lastNames[index] << endl;

	}
	cout << endl << endl;
}

void PrintTotals(const int ID[], const double savingsAccount[], const double checkingAccount[], int size) {

	cout << setw(10) << left << "ID: ";
	cout << setw(20) << "Savings Account: ";
	cout << setw(20) << "Checking Account: ";
	cout << setw(10) << "Total: " << endl;

	for (int index = 0; index < size; ++index) {

		cout << setw(10) << ID[index];
		cout << setw(20) << savingsAccount[index];
		cout << setw(20) << checkingAccount[index];
		cout << setw(10) << checkingAccount[index] + savingsAccount[index] << endl;
	}
	cout << endl << endl;
}


int main() {
	int ID[10];
	string firstNames[10];
	string lastNames[10];
	double savingsAccount[10];
	double checkingAccount[10];
	ifstream inCD; //"in Customer Data"
	char userOption = 0;
	string fileName = "input.txt";
	int lineIndex = 0;

	inCD.open(fileName);

	if (inCD.fail()) {
		cout << "Opening of input file failed, please try again." << endl;
	}

	while (!inCD.eof()) {
		inCD >> ID[lineIndex];
		inCD >> firstNames[lineIndex];
		inCD >> lastNames[lineIndex];
		inCD >> savingsAccount[lineIndex];
		inCD >> checkingAccount[lineIndex];
		++lineIndex;
	}

	int size = lineIndex; //New variable declared to make program more explicit


	while (userOption != 'Q') {

		outputMenu();
		cin >> userOption;
		cout << endl;

		switch (userOption) {

		case ('1'):
			PrintCustomerData(ID, firstNames, lastNames, savingsAccount, checkingAccount, size);
			break;
		case ('2'):
			PrintNames(ID, firstNames, lastNames, size);
			break;
		case ('3'):
			PrintTotals(ID, savingsAccount, checkingAccount, size);
		default:
			userOption = (isalpha(userOption)) ? toupper(userOption) : userOption;
			break;
		}
	}
}